"""Probes for the Notebook Review Framework v1 review of tutorials/mobilenetv4_classification_colab.ipynb.

Reviewed revision: kurtvalcorza/mobilenetv4-classification-pipeline @ fcb47663cd1480fdc12290c92cbc638007b7b2a6
(notebook blob 484cc1023f6e577a9c1b9db48a0dd9729c3a0e8f).

Direct execution is LOCAL CPU ONLY (CUDA_VISIBLE_DEVICES=-1) in the pinned build venv `dimer-next16`
(python 3.12.10, torch 2.14.0+cu130, torchvision 0.29.0, timm 1.0.29, numpy 2.5.3, pillow 11.3.0,
safetensors 0.8.0, huggingface-hub 0.36.2 = the notebook PINS). The install cell is skipped through the
notebook's own DIMER_NOTEBOOK_CI_PREINSTALLED=1 switch. `google.colab.files.upload` is replaced by a shim
that returns prepared bytes. HF_HOME points at a scratch directory (clean cache). It is NOT a Colab run.

Usage: python run_probes.py <worktree> <scratch_dir>
Writes results.json and source_manifest.json next to this script.
"""
import contextlib
import copy
import hashlib
import io
import json
import os
import sys
import time
import traceback
import types
import zipfile

WT = sys.argv[1]
SCRATCH = sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__))
NB_PATH = os.path.join(WT, 'tutorials', 'mobilenetv4_classification_colab.ipynb')
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['HF_HOME'] = os.path.join(SCRATCH, 'hf_home')
os.environ['HF_HUB_DISABLE_PROGRESS_BARS'] = '1'
os.environ.setdefault('OMP_NUM_THREADS', '6')  # host shared with other sessions' probes; 24 threads oversubscribed
os.makedirs(SCRATCH, exist_ok=True)

RESULTS = {}
_prev = os.path.join(HERE, 'results_attempt1.json')
if os.path.exists(_prev):
    RESULTS['attempt1_killed_at_590s_P2_default_run'] = json.load(open(_prev, encoding='utf-8')).get('P2_default_run')


def save():
    with open(os.path.join(HERE, 'results.json'), 'w', encoding='utf-8') as fh:
        json.dump(RESULTS, fh, indent=1, default=str)


def sha256_file(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


# ---------------------------------------------------------------- source manifest
SOURCES = [
    'tutorials/mobilenetv4_classification_colab.ipynb', 'tutorials/README.md',
    'src/mobilenetv4_classification_pipeline/pipeline.py', 'tools/build_notebook.py',
    'tools/notebook_template.py', 'tools/validate_release_assets.py', 'docs/release-verification.md',
    'README.md', 'STATUS.md', 'MODEL_CARD.md', 'pyproject.toml', 'tests/test_pipeline.py',
    'tests/test_notebook_parity.py', 'weights/mobilenetv4-conv-small/dimer-base-manifest.json',
]
with open(os.path.join(HERE, 'source_manifest.json'), 'w', encoding='utf-8') as fh:
    json.dump({'repository': 'kurtvalcorza/mobilenetv4-classification-pipeline',
               'revision': 'fcb47663cd1480fdc12290c92cbc638007b7b2a6',
               'files': {p: sha256_file(os.path.join(WT, p)) for p in SOURCES}}, fh, indent=1)

nb = json.load(open(NB_PATH, encoding='utf-8'))
CELLS = {i: ''.join(c['source']) for i, c in enumerate(nb['cells']) if c['cell_type'] == 'code'}
MD = '\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'markdown')
ALL = '\n'.join(''.join(c['source']) for c in nb['cells'])

# ---------------------------------------------------------------- P1 static
import re  # noqa: E402

RESULTS['P1_static'] = {
    'cells': len(nb['cells']), 'code_cells': sorted(CELLS),
    'metadata_dimer': nb['metadata'].get('dimer'),
    'pip_install_in_kernel': "'pip', 'install'" in ALL, 'uses_uv': 'uv venv' in ALL or 'uv pip' in ALL,
    'SAMPLE_HEIGHT_defined_anywhere': bool(re.search(r'^\s*SAMPLE_HEIGHT\s*=', ALL, re.M)),
    'SAMPLE_HEIGHT_used_in_cell17': 'SAMPLE_HEIGHT' in CELLS[17],
    'fallback_except_Exception_wraps_sha_check': 'except Exception as exc' in CELLS[17] and 'SHA-256 mismatch' in CELLS[17],
    'fit_optimizer_all_params': 'AdamW(model.parameters()' in open(os.path.join(WT, 'src/mobilenetv4_classification_pipeline/pipeline.py'), encoding='utf-8').read(),
    'fit_shuffles_training_order': 'shuffle' in open(os.path.join(WT, 'src/mobilenetv4_classification_pipeline/pipeline.py'), encoding='utf-8').read().split('def fit(')[1].split('def _validate')[0],
    'fit_seeds_torch': 'manual_seed' in open(os.path.join(WT, 'src/mobilenetv4_classification_pipeline/pipeline.py'), encoding='utf-8').read(),
    'verdict_success_hardcoded_cell19': "'verdict': 'success'" in CELLS[19],
    'cell19_compares_reloaded_to_in_memory': 'fine_tuned_pipe' in CELLS[19],
    'prose_head_only_claims': [s for s in ['new classification head', 'head adaptation', 'classification head fine-tuning'] if s in ALL],
    'prereq_says_nothing_downloaded': 'nothing is downloaded' in MD,
    'prereq_external_access_mentions_dataset': 'cifar' in ''.join(nb['cells'][1]['source']).lower(),
    'markdown_mentions_restart': 'restart' in MD.lower(),
    'expected_result_notes_cells_17_19': ['Look for' in ''.join(nb['cells'][16]['source']), 'Look for' in ''.join(nb['cells'][18]['source'])],
    'guided_markers': {k: (k.lower() in MD.lower()) for k in ['How to use', 'Roadmap', 'Glossary', 'Predict', 'Troubleshooting', 'Checkpoint', 'Infrastructure', 'conclusion']},
    'spec_declared': nb['metadata'].get('dimer', {}).get('notebook_spec'),
}
save()

# ---------------------------------------------------------------- harness
UPLOAD = {'value': {}}
colab = types.ModuleType('google.colab')
colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD['value']))
google = types.ModuleType('google')
google.colab = colab
sys.modules.setdefault('google', google)
sys.modules['google.colab'] = colab


def subst(src, mapping):
    for old, new in mapping.items():
        if old not in src:
            raise KeyError(f'substitution target not found: {old!r}')
        src = src.replace(old, new)
    return src


def run_cells(ns, idxs, subs=None, label=''):
    """Execute code cells in ns; stop at first error. Returns list of per-cell records."""
    recs = []
    for i in idxs:
        src = CELLS[i]
        if subs and i in subs:
            src = subst(src, subs[i])
        out = io.StringIO()
        t0 = time.time()
        try:
            with contextlib.redirect_stdout(out):
                exec(compile(src, f'<cell {i}>', 'exec'), ns)
            recs.append({'cell': i, 'ok': True, 's': round(time.time() - t0, 2), 'stdout_tail': out.getvalue()[-1500:]})
        except BaseException as exc:  # noqa: BLE001
            recs.append({'cell': i, 'ok': False, 's': round(time.time() - t0, 2), 'error': f'{type(exc).__name__}: {exc}'[:600],
                         'stdout_tail': out.getvalue()[-800:], 'tb_tail': traceback.format_exc()[-600:]})
            break
    return recs


def fresh_dir(name):
    d = os.path.join(SCRATCH, name)
    os.makedirs(d, exist_ok=True)
    os.chdir(d)
    return d


# ---------------------------------------------------------------- P2 clean default run
t0 = time.time()
fresh_dir('default')
NS = {'__name__': '__main__'}
recs = run_cells(NS, [3, 5, 7, 9, 11, 13, 15, 17, 19, 21])
RESULTS['P2_default_run'] = {
    'cells': recs, 'all_ok': all(r['ok'] for r in recs) and len(recs) == 10, 'wall_s': round(time.time() - t0, 1),
    'outputs': sorted(os.listdir('outputs')) if os.path.isdir('outputs') else None,
    'train_targets_order': NS.get('train_targets'), 'val_targets': NS.get('val_targets'),
    'history': NS.get('train_meta', {}).get('history'),
    'val_accuracy': NS.get('val_accuracy'), 'majority_baseline': NS.get('majority_baseline'),
    'report_verdict': NS.get('finetuned_eval_report', {}).get('verdict'),
    'dataset_source': NS.get('dataset_source'),
}
save()
import numpy as np  # noqa: E402
import torch  # noqa: E402

DEF = NS  # keep the default namespace (pipe, images, zip bytes)
from pathlib import Path  # noqa: E402
DEF['WEIGHTS_DIR'] = Path(os.path.join(SCRATCH, 'default')) / DEF['WEIGHTS_DIR']  # cwd-relative in the notebook; probes chdir per case
DEF['ft_output_dir_default'] = DEF['ft_output_dir']

# ---------------------------------------------------------------- P3 reload equivalence (never checked by the notebook)
ft, rl = DEF['fine_tuned_pipe'], DEF['reloaded_pipe']
diffs = []
for img in DEF['val_images']:
    a = ft.predict(img)['predictions'][0]['top_k']
    b = rl.predict(img)['predictions'][0]['top_k']
    diffs.append(max(abs(x['score'] - y['score']) for x, y in zip(sorted(a, key=lambda z: z['index']), sorted(b, key=lambda z: z['index']))))
RESULTS['P3_reload_equivalence'] = {'max_abs_score_diff': max(diffs), 'n': len(diffs),
                                    'note': 'computed by the probe; the notebook only loads and evaluates the reloaded model'}
save()

# ---------------------------------------------------------------- P4 repeatability of the default fine-tune (fit seeds nothing)
from PIL import Image  # noqa: E402

pipe = DEF['pipe']
MV = DEF['MobileNetV4ClassificationPipeline']
TI, TT, VI, VT, CC, WD = (DEF['train_images'], DEF['train_targets'], DEF['val_images'], DEF['val_targets'],
                          DEF['CUSTOM_CLASSES'], DEF['WEIGHTS_DIR'])


def acc_of(p, imgs, tgts):
    hits = 0
    for img, t in zip(imgs, tgts):
        hits += int(p.predict(img)['predictions'][0]['predicted_index'] == t)
    return round(hits / len(tgts), 4)


def fit_once(seed, ti, tt, epochs=1, lr=1e-4, bs=4):
    if seed is not None:
        torch.manual_seed(seed)
    p, meta = MV.fit(train_images=ti, train_targets=tt, val_images=VI, val_targets=VT, class_names=CC,
                     epochs=epochs, batch_size=bs, learning_rate=lr, weights_dir=WD, output_dir=None)
    return {'val_acc': acc_of(p, VI, VT), 'history': meta['history']}


rep = {'unseeded_repeats': [fit_once(None, TI, TT) for _ in range(2)],
       'seeded_0_2_as_shipped_class_sorted_order': [fit_once(s, TI, TT) for s in range(3)]}
# Diagnostic variant (not a notebook path): same data, training order interleaved by a seeded shuffle.
import random  # noqa: E402

order = list(range(len(TI)))
random.Random(0).shuffle(order)
rep['seeded_0_2_shuffled_order'] = [fit_once(s, [TI[i] for i in order], [TT[i] for i in order]) for s in range(3)]
RESULTS['P4_finetune_repeatability'] = rep
save()

# ---------------------------------------------------------------- P5 zero-shot ImageNet grouping baseline on the same split
FROG = [30, 31, 32]  # bullfrog, tree frog, tailed frog
TRUCK = [555, 569, 675, 717, 864, 867]  # fire engine, garbage truck, moving van, pickup, tow truck, trailer truck


def zero_shot(imgs):
    preds = []
    for img in imgs:
        tk = pipe.predict(img, top_k=1000)['predictions'][0]['top_k']
        s = {d['index']: d['score'] for d in tk}
        frog, truck = sum(s[i] for i in FROG), sum(s[i] for i in TRUCK)
        preds.append(CC.index('frog') if frog > truck else CC.index('truck'))
    return preds


zs_val = zero_shot(VI)
zs_train = zero_shot(TI)
RESULTS['P5_zero_shot_grouped'] = {
    'imagenet_groups': {'frog': FROG, 'truck': TRUCK},
    'val_acc': round(sum(int(a == b) for a, b in zip(zs_val, VT)) / len(VT), 4),
    'train_acc': round(sum(int(a == b) for a, b in zip(zs_train, TT)) / len(TT), 4),
}
save()

# ---------------------------------------------------------------- P6 dataset structure and duplicates
zb = DEF['zip_bytes']
with zipfile.ZipFile(io.BytesIO(zb)) as z:
    names = [n for n in z.namelist() if n.lower().endswith(('.png', '.jpg', '.jpeg', '.webp', '.bmp')) and not n.startswith('__MACOSX')]
    hashes = {}
    for n in names:
        arr = np.asarray(Image.open(io.BytesIO(z.read(n))).convert('RGB'))
        hashes[n] = hashlib.sha256(arr.tobytes()).hexdigest()
from collections import Counter, defaultdict  # noqa: E402

groups = defaultdict(list)
for n, h in hashes.items():
    groups[h].append(n)
dup_groups = [g for g in groups.values() if len(g) > 1]
classes = Counter(n.strip('/').split('/')[-2] for n in names)
# Reproduce the notebook's subset/split selection to see which files were used
rng = random.Random(42)
by_cls = defaultdict(list)
for n in names:
    by_cls[n.strip('/').split('/')[-2]].append(n)
sel_train, sel_val = [], []
for cls, files in by_cls.items():
    f = list(files)
    rng.shuffle(f)
    f = f[:16]
    nv = max(1, int(len(f) * 0.2))
    sel_val += f[:nv]
    sel_train += f[nv:]
train_h = {hashes[n] for n in sel_train}
all_other_h = Counter(hashes.values())
leak_by_subset = {}
for k in (16, 50, 100, 200):
    rng_k = random.Random(42)
    tr_k, va_k = [], []
    for cls, files in by_cls.items():
        f = list(files)
        rng_k.shuffle(f)
        f = f[:k]
        nv = max(1, int(len(f) * 0.2))
        va_k += f[:nv]
        tr_k += f[nv:]
    th = {hashes[n] for n in tr_k}
    leak_by_subset[k] = {'val': len(va_k), 'val_with_exact_copy_in_train': sum(hashes[n] in th for n in va_k)}
RESULTS['P6_dataset'] = {'leak_by_SUBSET_PER_CLASS': leak_by_subset,
    'n_images': len(names), 'per_class': dict(classes), 'top_level_entries': sorted({n.split('/')[0] for n in z.namelist()})[:10],
    'example_paths': names[:3], 'has_train_dir': any('train/' in n.lower() for n in names),
    'exact_pixel_duplicate_groups': len(dup_groups), 'images_in_dup_groups': sum(len(g) for g in dup_groups),
    'dup_examples': dup_groups[:3],
    'selected_val': sel_val, 'val_with_exact_copy_in_selected_train': sum(hashes[n] in train_h for n in sel_val),
    'val_with_exact_copy_anywhere_else_in_zip': sum(all_other_h[hashes[n]] > 1 for n in sel_val),
    'val_image_mean_brightness': [round(float(np.asarray(im).mean()), 1) for im in VI],
    'train_mean_brightness_min_max': [round(min(float(np.asarray(im).mean()) for im in TI), 1), round(max(float(np.asarray(im).mean()) for im in TI), 1)],
    'image_size': list(VI[0].size),
}
save()

# ---------------------------------------------------------------- P7 sample-dataset failure handling (fallback branch)
import urllib.request  # noqa: E402

real_urlopen = urllib.request.urlopen


class _Fake:
    def __init__(self, data):
        self.data = data

    def read(self):
        return self.data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


fb = {}
fresh_dir('fallback_offline')
ns = dict(DEF)
urllib.request.urlopen = lambda *a, **k: (_ for _ in ()).throw(OSError('simulated: network unreachable'))
fb['offline'] = run_cells(ns, [17])
_tampered = zb[:1000] + bytes([zb[1000] ^ 0xFF]) + zb[1001:]  # flip one byte inside the archive
urllib.request.urlopen = lambda *a, **k: _Fake(_tampered)
fresh_dir('fallback_tampered')
ns = dict(DEF)
fb['tampered_zip_sha_mismatch'] = run_cells(ns, [17])
urllib.request.urlopen = real_urlopen
RESULTS['P7_dataset_fallback'] = fb
save()

# ---------------------------------------------------------------- P8 BYOD single image (cells 9-15 and 21)
frog_img = VI[VT.index(CC.index('frog'))]
truck_img = VI[VT.index(CC.index('truck'))]


def png(img):
    b = io.BytesIO()
    img.save(b, format='PNG')
    return b.getvalue()


byod = {}
cases = {
    'truck_photo_gt_867': ({'truck.png': png(truck_img.resize((224, 224)))}, '867'),
    'text_as_png': ({'notes.png': b'this is not an image'}, '-1'),
    'oversized_5000px': ({'big.png': png(Image.new('RGB', (5000, 10)))}, '-1'),
    'gt_out_of_range': ({'truck.png': png(truck_img)}, '1000'),
    'empty_upload': ({}, '-1'),
}
for name, (upl, gt) in cases.items():
    _d = fresh_dir('byod_img_' + name)
    import shutil
    shutil.copytree(os.path.join(SCRATCH, 'default', DEF['ft_output_dir']), os.path.join(_d, DEF['ft_output_dir']), dirs_exist_ok=True)  # cell 21 lists the fine-tune dir written earlier in Run all
    ns = dict(DEF)
    UPLOAD['value'] = upl
    recs = run_cells(ns, [9, 11, 13, 15, 21], subs={9: {'USE_BYOD = False': 'USE_BYOD = True', 'GROUND_TRUTH_INDEX = -1': f'GROUND_TRUTH_INDEX = {gt}'}})
    byod[name] = {'cells': [{k: v for k, v in r.items() if k != 'stdout_tail'} | ({'stdout_tail': r['stdout_tail'][-400:]}) for r in recs],
                  'verdict': ns.get('report', {}).get('verdict') if ns.get('report') is not DEF.get('report') else None,
                  'metrics': ns.get('report', {}).get('metrics') if ns.get('report') is not DEF.get('report') else None}
RESULTS['P8_byod_image'] = byod
save()

# ---------------------------------------------------------------- P9 BYOD dataset zip (cells 17, 19, 21)


def make_zip(entries):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for path, data in entries:
            z.writestr(path, data)
    return b.getvalue()


frogs = [im for im, t in zip(TI, TT) if t == CC.index('frog')]
trucks = [im for im, t in zip(TI, TT) if t == CC.index('truck')]
two_class = [(f'mydata/frog/f{i}.png', png(frogs[i])) for i in range(6)] + [(f'mydata/truck/t{i}.png', png(trucks[i])) for i in range(6)]
presplit = ([(f'train/frog/f{i}.png', png(frogs[i])) for i in range(4)] + [(f'train/truck/t{i}.png', png(trucks[i])) for i in range(4)]
            + [(f'val/frog/f{i}.png', png(frogs[i + 4])) for i in range(2)] + [(f'val/truck/t{i}.png', png(trucks[i + 4])) for i in range(2)]
            + [('val/cat/c0.png', png(frogs[10]))])
zcases = {  # noqa: E501
    'class_folders_2x6': ('data.zip', make_zip(two_class)),
    'presplit_train_val_with_val_only_class': ('data.zip', make_zip(presplit)),
    'one_class': ('data.zip', make_zip([(f'frog/f{i}.png', png(frogs[i])) for i in range(4)])),
    'class_with_one_image': ('data.zip', make_zip(two_class[:6] + [('mydata/truck/t0.png', png(trucks[0]))])),
    'traversal_member': ('data.zip', make_zip(two_class + [('../evil.png', png(frogs[0]))])),
    'undecodable_member': ('data.zip', make_zip(two_class + [('mydata/frog/bad.png', b'not an image')])),
    'root_level_images_plus_one_folder': ('data.zip', make_zip([(f'f{i}.png', png(frogs[i])) for i in range(4)] + [(f'truck/t{i}.png', png(trucks[i])) for i in range(4)])),
    'tar_not_zip': ('data.tar', b'0' * 100),
}
zr = {}
for name, (fname, data) in zcases.items():
    fresh_dir('byod_ds_' + name)
    ns = dict(DEF)
    UPLOAD['value'] = {fname: data}
    torch.manual_seed(0)
    recs = run_cells(ns, [17, 19, 21], subs={17: {'USE_BYOD_DATASET = False': 'USE_BYOD_DATASET = True'}})
    zr[name] = {'cells': [{k: v for k, v in r.items() if k != 'tb_tail'} for r in recs],
                'classes': ns.get('CUSTOM_CLASSES') if recs and recs[0]['ok'] else None,
                'n_train': len(ns['train_images']) if recs and recs[0]['ok'] else None,
                'n_val': len(ns['val_images']) if recs and recs[0]['ok'] else None,
                'outputs': sorted(os.listdir('outputs')) if os.path.isdir('outputs') else None}
RESULTS['P9_byod_dataset'] = zr
save()

# ---------------------------------------------------------------- P10 active learning: re-run cell 17 + 19 twice (documented rerun = none)
fresh_dir('rerun')
ns = dict(DEF)
r1 = run_cells(ns, [17, 19])
a1 = ns.get('val_accuracy')
r2 = run_cells(ns, [17, 19])
a2 = ns.get('val_accuracy')
# Larger subset: SUBSET_PER_CLASS is a plain constant (not a form field); change it and re-run 17-19.
ns3 = dict(DEF)
torch.manual_seed(0)
r3 = run_cells(ns3, [17, 19], subs={17: {'SUBSET_PER_CLASS = 16': 'SUBSET_PER_CLASS = 50'}})
RESULTS['P10_rerun'] = {'rerun_1_val_acc': a1, 'rerun_2_val_acc': a2, 'ok': all(r['ok'] for r in r1 + r2),
                        'subset_per_class_50': {'ok': all(r['ok'] for r in r3), 'n_train': len(ns3.get('train_images', [])),
                                      'n_val': len(ns3.get('val_images', [])), 'val_acc': ns3.get('val_accuracy'),
                                      'majority': ns3.get('majority_baseline'), 'history': ns3.get('train_meta', {}).get('history')}}
save()
RESULTS['total_wall_s'] = round(time.time() - t0, 1)
save()
print('done', RESULTS['total_wall_s'])
